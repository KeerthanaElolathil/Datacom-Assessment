package StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MonthlyCycleRepeats {
	
	@Given("that registered employee with Monthly pay frequency has login the system")
	public void that_registered_employee_with_monthly_pay_frequency_has_login_the_system() {
		System.out.println("inside step - login the system with registered employee with pay frequency Monthly");
	}

	@Given("the employee should complete atleast one pay cycle successfully")
	public void the_employee_should_complete_atleast_one_pay_cycle_successfully() {
		System.out.println("inside step - the employee should complete atleast one pay cycle");
	}

	@When("the user is on a Monthly pay frequency the salary is calculated for a period of one month")
	public void the_user_is_on_a_Monthly_pay_frequency_the_salary_is_calculated_for_a_period_of_one_month() {
		System.out.println("inside step - For Monthly pay frequency salary is calculated for a period of one month");
	}

	@Then("the pay frequency for the current and upcoming pay period should remain Monthly unless the employee change the pay frequency in the system")
	public void the_pay_frequency_for_the_current_and_upcoming_pay_period_should_remain_monthly_unless_the_employee_change_the_pay_frequency_in_the_system() {
		 System.out.println("inside step - the pay frequency for the current and upcoming pay period should remain Monthly unless the employee change the pay frequency in the system");
	}


}
