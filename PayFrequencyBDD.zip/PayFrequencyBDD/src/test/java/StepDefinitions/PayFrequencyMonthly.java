package StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PayFrequencyMonthly {
	
	@Given("the pay frequency is set to Monthly")
	public void the_pay_frequency_is_set_to_monthly() {
	   System.out.println("inside step - pay frequency is set as Monthly");   
	}

	@When("calculate the pay period")
	public void user_calculate_the_pay_period() {
	    System.out.println("inside step - calculate the pay period");
	}

	@Then("the pay period start date shall be a month prior to the pay period end date")
	public void the_pay_period_start_date_shall_be_a_month_prior_to_the_pay_period_end_date() {
	    System.out.println("inside step-pay period start date is one month pror to pay period end date");
	}

}
