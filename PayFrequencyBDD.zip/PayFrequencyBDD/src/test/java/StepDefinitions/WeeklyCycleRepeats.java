package StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WeeklyCycleRepeats {
	
	@Given("Login dashboard of a registered employee with pay frequency Weekly")
	public void login_dashboard_of_a_registered_employee_with_pay_frequency_weekly() {
	    System.out.println("inside step - employee shall be registered with pay frequency Weekly");
	}

	@Given("Employee should complete one pay cycle successfully")
	public void employee_should_complete_one_pay_cycle_successfully() {
	    System.out.println("inside step - employee shall complete atleast one pay cycle successfully");
	}

	@When("the user is on a Weekly pay frequency the salary is calculated for a period of {int} days")
	public void the_user_is_on_a_weekly_pay_frequency_the_salary_is_calculated_for_a_period_of_days(Integer int1) {
	    System.out.println("inside step - For weekly pay frequency salary is calculated for a period of 7 days");
	}

	@Then("the pay frequency for the current and upcoming pay period should remain Weekly unless the employee change the pay frequency in the system")
	public void the_pay_frequency_for_the_current_and_upcoming_pay_period_should_remain_weekly_unless_the_employee_change_the_pay_frequency_in_the_system() {
	    System.out.println("inside step - the pay frequency for the current and upcoming pay period should remain Weekly unless the employee change the pay frequency in the system");
	}

}
