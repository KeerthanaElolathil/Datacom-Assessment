package StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PayFrequencyFortnightly {
	
	@Given("the pay frequency is set to fortnightly")
	public void the_pay_frequency_is_set_to_fortnightly() {
	    System.out.println("inside step - pay frequency is set as fortnightly");
	 }
	@When("user calculates the pay period")
	public void user_calculates_the_pay_period() {
	    System.out.println("inside step - user calculates the pay period");
	}

	@Then("the pay period start date shall be two weeks prior to the pay period end date")
	public void the_pay_period_start_date_shall_be_two_weeks_prior_to_the_pay_period_end_date() {
	    System.out.println("inside step- pay period start date is two weeks prior to pay period end date");
	    }

}
