package StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class FortnightlyCycleRepeats {
	
	@Given("that registered employee with Fortnightly pay frequency has login the system")
	public void that_registered_employee_with_fortnightly_pay_frequency_has_login_the_system() {
	    System.out.println("inside step - login the system with registered employee with pay frequency Fortnightly");

	}

	@Given("the employee should complete one pay cycle successfully")
	public void the_employee_should_complete_one_pay_cycle_successfully() {
	    System.out.println("inside step - the employee should complete atleast one pay cycle");
	}

	@When("the user is on a Fortnightly pay frequency the salary is calculated for a period of two weeks")
	public void the_user_is_on_a_fortnightly_pay_frequency_the_salary_is_calculated_for_a_period_of_two_weeks() {
		 System.out.println("inside step - For Fortnightly pay frequency salary is calculated for a period of two weeks");
	}

	@Then("the pay frequency for the current and upcoming pay period should remain Fortnightly unless the employee change the pay frequency in the system")
	public void the_pay_frequency_for_the_current_and_upcoming_pay_period_should_remain_fortnightly_unless_the_employee_change_the_pay_frequency_in_the_system() {
		 System.out.println("inside step - the pay frequency for the current and upcoming pay period should remain Fortnightly unless the employee change the pay frequency in the system");
	}

}
