package StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PayFrequencyWeekly {
	
	@Given("the pay frequency is set to Weekly")
	public void the_pay_frequency_is_set_to_Weekly() {
	    System.out.println("inside step - the pay frequency is set as weekly");
	    }

	@When("user calculate the pay period")
	public void user_calculate_the_pay_period() {
	    System.out.println("inside step - user calculates the pay period");
	   }

	@Then("the pay period start date shall be one week prior to the pay period end date")
	public void the_pay_period_start_date_shall_be_one_week_prior_to_the_pay_period_end_date() {
		System.out.println("inside step - Pay periods date range shall be aligned to pay period end date");
	    }

}
