package StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.core.cli.Main;

public class LeaveOnWorkingDay1 {
	
	@Given("an employee with zero leave balance")
	public void an_employee_with_zero_leave_balance() {
	    System.out.println("inside step - employee should have zero leave balance");
	}

	@When("the employee has taken leave on working day")
	public void the_employee_has_taken_leave_on_working_day() {
	    System.out.println("inside step - employee has taken leave on working day");
	}

	@Then("the salary should be deducted based on the number of days the employee was on leave")
	public void the_salary_should_be_deducted_based_on_the_number_of_days_the_employee_was_on_leave() {
	    System.out.println("inside step - the salary should be deducted based on the number of days the employee was on leave");
	}

}
