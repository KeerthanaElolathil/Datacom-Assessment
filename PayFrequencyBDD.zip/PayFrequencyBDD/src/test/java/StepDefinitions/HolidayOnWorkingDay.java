package StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HolidayOnWorkingDay {
	
	@Given("an employee works on all working days defined in the pay period")
	public void an_employee_works_on_all_working_days_defined_in_the_pay_period() {
	   System.out.println("inside step - employee should be working on all predefined working days in the pay period");
	}

	@When("the employee has a holiday on a working day")
	public void the_employee_has_a_holiday_on_a_working_day() {
	    System.out.println("inside step - a holiday falls on the working day");
	}

	@Then("the salary should not be deduced")
	public void the_salary_should_not_be_deduced() {
	    System.out.println("inside step - the salary should not be deduced");
	}

	@Then("a Statutory Holiday Taken leave item shall be populated for the holiday date")
	public void a_statutory_holiday_taken_leave_item_shall_be_populated_for_the_holiday_date() {
	    System.out.println("inside step - a Statutory Holiday Taken leave item should populate for the holiday date");
	}

}
