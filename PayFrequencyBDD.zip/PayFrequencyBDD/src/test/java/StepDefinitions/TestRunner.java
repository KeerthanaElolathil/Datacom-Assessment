package StepDefinitions;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/resources/Features", glue = {"StepDefinitions"},
monochrome = true, 
tags = ("@login or @WeeklyPayroll or @FortnightlyPayroll or @MonthlyPayRoll or @LeaveOnWorkingDay2 or @LeaveOnWorkingDay1"
		+ "@HolidayOnWorkingDay or @CycleRepeatsFortnightly or @CycleRepeatsWeekly or @CycleRepeatsMonthly"))
public class TestRunner {

}
