package StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.core.cli.Main;

public class LeaveOnWorkingDay2 {


@Given("an employee with active leave balance")
public void an_employee_with_active_leave_balance() {
    System.out.println("inside step - employee should have active leave balance");
}

@When("the employee has taken leave on working days")
public void the_employee_has_taken_leave_on_working_days() {
    System.out.println("inside step - employee has taken leave on working days");
}

@Then("the salary of employee should not be deducted")
public void the_salary_of_employee_should_not_be_deducted() {
    System.out.println("inside step - salary of employee should not get deducted");
}
}
